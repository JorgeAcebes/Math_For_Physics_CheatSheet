Cuando lo actualices, sube ese file a GitHub

Constants

Tensors (ACTUALIZA CON EL DE RG, PORQUE TIENE MÁS COSAS)

Odes